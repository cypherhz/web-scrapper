# Importing the Libraries
import requests
from bs4 import BeautifulSoup
import html5lib
# import lxml
import pandas as pd
import csv

# Defining the URL
url1= "http://localhost/spicyo/"

codes = requests.get(url1)
content = codes.content

# Creating the Soup Object
soup = BeautifulSoup(content, 'html.parser')

# Extracting the Title of the Page
# print("Extracting the Title of the Page")
# print("-----------------------------------")
title = soup.find('title').text
# print(title)
# print()

# # Extracting whole text from the page
# print("Extracting whole text from the page")
# print("-----------------------------------")
whole_text = soup.text
# for text in whole_text:
    # print(text)
# print()

# # Extracting all Links from the page
# print("Extracting all Links from the page")
# print("-----------------------------------")
anchors = soup.find_all('a')
valid_links = set()
for link in anchors:
    if (link.get('href') != "#"):
        link = "http://spicyo.com/"+link.get('href')
        valid_links.add(link)
valid_links = list(valid_links)
# for link in valid_links:
#     print(link)
# print()

# # Extracting the Name of the Links
# print("Extracting all the Names of the Links from the page")
# print("-----------------------------------")
all_links = set()
links = soup.find_all('a')
for x in links:
    a = x.string
    all_links.add(a)
all_links = list(all_links)
# for j in all_links:
#     print(j)
# print()

# Extracting the Menu Contents
# print("Extracting all the Names of the Links from the page")
# print("-----------------------------------")
menu_ul = soup.find(id="sidebar").ul
menu_anchors = menu_ul.find_all('a')
menu = set()
menu_link= set()
for menu_cont in menu_anchors:
    menu.add(menu_cont.text)
    menu_link.add(menu_cont.get('href'))
menu = list(menu)
menu_link = list(menu_link)
#  print(menu)
# print(menu_link)
# print()

# Iterating to the all menu pages of the website
# for link_iter in menu_link:
#     url= f"http://localhost/spicyo/{link_iter}"
#     cont = requests.get(url)
#     htmlcont = cont.content
#     soup1 = BeautifulSoup(htmlcont, 'html.parser')
#     print(soup1.prettify)

# Extracting all the images from the page
imgtag = soup.find_all('img')
images = set()
for link in imgtag:
    images.add(f"http://localhost/spicyo/{link.get('src')}")
images = list(images)
# for img in images:
#     print(img)

# Extracting all the products from the pages
products = soup.find_all(class_ = "product_blog_cont")
dishes = set()
dish_prices = set()
for product in products:
    dishes.add(product.find('h3').text)
    dish_prices.add(product.find('h4').text)
dishes = list(dishes)
dish_prices = list(dish_prices)
# print(dishes)
# print(dish_prices)

# Extracting Blog posts and its contents
blog_class = soup.find_all(class_ = "blog_box")
post_name = set()
post_content = list()
for x in blog_class:
    blogname = x.find('h3').text
    blog_content = x.find('p').text
    post_name.add(blogname)
    post_content.append(blog_content)
post_name = list(post_name)
# print(post_name)
# print(post_content)

# -----------------------------> End of the Web Scrapping <-----------------------------#



website_link_names = pd.DataFrame({'Link Name': all_links})
website_links = pd.DataFrame({'Links': valid_links})
website_menu_names = pd.DataFrame({'Name of the Menus': menu})
website_menu_links = pd.DataFrame({'Menu Links': menu_link})
website_images = pd.DataFrame({'Images Links': images})
website_products = pd.DataFrame({'Dishes Names': dishes, 'Prices': dish_prices})
website_blog = pd.DataFrame({'Post Name': post_name, 'Post Content': post_content}) 

website_sheets = {'Link Names': website_link_names, 'Links': website_links, 'Menus': website_menu_names, 'Menu Links': website_menu_links, 'Images': website_images, 'Dishes': website_products, 'Blog': website_blog}

writer = pd.ExcelWriter('Excel_Files/result.xlsx', engine='xlsxwriter')

for sheet_name in website_sheets.keys():
    website_sheets[sheet_name].to_excel(writer, sheet_name=sheet_name, index=False)

writer.save()

# -----------------------------> End of the .xlsx creation <-----------------------------#

# Creating the Product File
dish_dict = {}

for i in range (len(dishes)):
    dish_dict[dishes[i]] = dish_prices[i]
# print(dish_dict)

product_dict = [dish_dict]
csvfile=open('Csv_Files/products.csv','w', newline='')
fields=list(product_dict[0].keys())
obj=csv.DictWriter(csvfile, fieldnames=fields)
obj.writeheader()
obj.writerows(product_dict)
csvfile.close()

# -----------------------------> End of the .csv creation <-----------------------------#

# -----------------------------> Creation of the Text Files <----------------------------#
# Creating the whole text fies
for count_name in (menu): 
    file1 = open(f"Whole_Texts/{count_name} texts.txt","w")
    file1.write(whole_text)
    file1.close()

#file1 = open(f"All_Links/{count_name} texts.txt","w")
#print(type(all_links))
#for x in all_links:
#    file1.write(x)
#file1.close()
# ------------------------------> End of the Text Files Creation <------------------------#

